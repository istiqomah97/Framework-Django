from django.shortcuts import render
from dashboard.forms import FormBarang
from dashboard.models import Barang, perpus, Transaksi

# Create your views here.


def tambah_barang(request):
    form = FormBarang
    konteks = {
        'form': form,
    }
    return render(request, 'tambah_barang.html', konteks)


def produk(request):
    titelnya = "Produk"
    konteks = {
        'titel': titelnya,
    }
    return render(request, 'produk.html', konteks)


def Barang_view(request):
    barangs = Barang.objects.all()

    konteks = {
        'barangs': barangs,
    }
    return render(request, 'tampil_barang.html', konteks)


def transaksi_view(request):
    Transaksis = Transaksi.objects.all()
    konteks = {
        'Transaksis': Transaksis,
    }
    return render(request, 'Transaksi.html', konteks)


def perpus_view(request):
    Perpuss = perpus.objects.all()
    konteks = {
        'Perpuss': Perpuss,
    }
    return render(request, 'perpus.html', konteks)
